const realName = document.querySelector("#name");

realName.addEventListener("click", () => {
    realName.innerHTML.valueOf("Neville");
    console.log("Event triggered");
});